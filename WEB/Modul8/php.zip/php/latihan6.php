<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Info Politeknik Balekambang</title>
</head>
<body>

    <?php
        // Data tentang Politeknik Balekambang
        $namaPoltek = "Politeknik Balekambang";
        $lokasi = "Jepara, Jawa Tengah";
        $tahunBerdiri = 2018;
        $jumlahProgramStudi = 3;

        // Menampilkan data menggunakan pernyataan echo
        echo "<h1>Selamat Datang di $namaPoltek</h1>";
        echo "<p>Terletak di $lokasi, $namaPoltek adalah sebuah institusi pendidikan tinggi yang berdiri sejak tahun $tahunBerdiri.</p>";
        echo "<p>Saat ini, $namaPoltek memiliki $jumlahProgramStudi program studi yang beragam.</p>";
    ?>

</body>
</html>
