<?php
  // Ini adalah tag panjang PHP
  $pesan = "Ini tag Panjang PHP";
  echo $pesan;
?>

<?= "Ini adalah tag pendek PHP_____________________________________" ?>

<script language="php">
  // Ini adalah tag script PHP, jarang digunakan
  $pesan_script = "ini script!";
    $pesan_script;
</script>


<%
   Dim variable1
   variable1 = "Hello, ASP!"
   Response.Write(variable1)
%>
