<footer class="blockquote-footer fixed-bottom text-center">Politeknik Balekambang Jepara <cite title="Source Title"><a
href="https://polibang.ac.id"
target="_blank">polibang.ac.id</a></cite></footer>
</body>
</html>