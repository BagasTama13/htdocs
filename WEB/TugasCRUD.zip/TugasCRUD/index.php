<!-- Header -->
<?php include "header.php"?>

<!-- Body -->
<div class="container mt-5">

    <h1 class="text-center">SELAMAT DATANG di Mentoring Data SURVEI Application!</h1>
    <p class="text-center">
       Website mentoring Survei berbasis CRUD Kabupaten Jepara
    </p>
    <div class="container">
        <form action="view/home.php" method="post">
            <div class="from-group text-center">
                <input type="submit" name="btn btn-primary mt-2" value="Let's Do it!" id="">
            </div>
        </form>
    </div>
</div>

<!-- Footer -->
<?php include "footer.php"?>